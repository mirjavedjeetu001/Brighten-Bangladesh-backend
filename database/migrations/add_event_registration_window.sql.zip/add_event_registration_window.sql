ALTER TABLE events
  ADD COLUMN registration_start DATETIME NULL AFTER event_date;
